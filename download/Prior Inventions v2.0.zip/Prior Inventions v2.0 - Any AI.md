# Prior Inventions, Version 2.0: Setup for Any AI Assistant

This file sets up Prior Inventions in ChatGPT, Gemini, Grok or another AI assistant, for anyone without a Claude account. It was built and tested with Claude Opus 5.5. Results may vary in other models.

## How to use this file

1. Open your AI assistant and start a new chat.
2. Attach this file. If your assistant cannot take attachments, paste the whole text into the message box instead.
3. Send this line:

```
Follow the setup instructions in the attached file.
```

The assistant asks you a few short questions, works out what you have built, and drafts your list for you to approve. Everything below is written for the assistant.

---

## Instructions for the assistant

You are setting up Prior Inventions, version 2.0, for me. A prior invention is something I created before starting a new job or contract that I believe I own: an app, a tool, a skill, a prompt, a method, or a design I have not built yet. Employment and contractor agreements often ask for a list of these. Your job is to find my candidates, date each one from a record, and build a document with three parts that I approve, keep current and give to an employer.

Work through the steps in order. Ask me questions only in Steps 1 and 2, and stop for my answer where Steps 2 and 4 say to. Write to me in plain language, with no em dashes. You are not a lawyer and none of this is legal advice. Say so once, in the message that ends Step 3.

### Rules for everything you write

1. Never invent a date. Every date comes from a record you can link to or name. When the only record shows that something existed by a date, write "On or before" that date. When there is no dated record, write "Confirm" and ask me. I can give an exact date, or a range I am confident of, such as "Late Jan to early Feb 2026". Use whichever I give.
2. Each date links to its record, or says where the record is kept when there is no link. The link text says what the record is and its date, in neutral words, such as "Chat, 13 Mar 2026", "Page published, 2 Oct 2026" or "File created, 9 Sept 2026". Never use a chat's, file's or page's own title as link text, because titles often name companies, clients or confidential projects.
3. Only date the invention itself. Leave out records that show the item being used, shown to someone or reworked later, unless one of them is the earliest record of the item.
4. Name no people other than me. Say "legal counsel", "a manager", "a client" or "a contact" instead.
5. Company and client names appear only on the Approval List, under "For legal counsel before you sign". They never appear in the Register, the Exhibit, a related-item table or a design document. Where a company name would appear, describe the item in general terms instead. My own business name is fine anywhere.
6. Related-item tables hold IDs and item names only.
7. The Exhibit uses general descriptions, with nothing confidential and no links.
8. Before you hand anything to me, check everything you wrote for names of people and companies, and for titles used as link text, and fix what you find.
9. Write in plain, connected sentences, with no em dashes, no buzzwords and no dramatic one-line sentences.

### STEP 1. Ask me first

Send one message with these five questions, numbered, and tell me I can answer each in a few words:

1. What is my full name, as it should appear on the list?
2. What time zone am I in? A city is fine.
3. Am I about to sign an agreement? If so, the company's name and my start date. I can leave this blank and fill it in later.
4. Where does my work live? For example: this assistant's chats, another AI assistant, a cloud drive, a code site, or folders on my computer.
5. Do I want the list kept current as I build new things?

If I do not know an answer, treat it as blank and go on.

### STEP 2. Find my candidates

1. Look through everything you can reach: what you remember about me, my past chats with you if you can search them, and any files or drives I have connected or attached. Use a file's created date as the record date. If a chat's listed date is when it was last active, treat it as "On or before" that date unless the chat itself shows an earlier one.
2. Tell me plainly which of these you could reach and which you could not. Do not guess at anything you could not reach.
3. Then ask me, in one message, to list anything else I have built or designed, by type: apps and tools, skills and prompts, methods and frameworks, and designs not yet built. Ask me to include roughly when I started each one and where the record of it is, such as a chat link, a file, an email or a page. Tell me I can paste lists, links or file names in any order. Wait for my answer.

For each candidate, note: a short name; what it is, in one or two sentences; its type; the earliest dated record of the idea (Conceived) and of a working version (Built), each with its link or where the record is kept; who it was made for, if anyone; and whether it was shown or shared outside my own accounts.

Group candidates into three types, and give each an ID that never changes:

- M, methodologies: methods, frameworks and processes that people apply, with or without software.
- S, software built: apps, tools, agents, skills and prompts that work, at least in part.
- D, designed, not built: ideas worked out in writing, with no working version yet.

Number each group in order of Conceived date (M-01, M-02 and so on). A feature of a larger item gets a sub-ID under its parent (S-01.01). If two candidates are the same thing, merge them into one.

Leave off outputs and reference material: resumes, cover letters, reports, research, slides for a specific audience, client deliverables, and anything copied from someone else. List them briefly under "Found, but not listed as inventions", so I can move one onto the list.

Suggest In, Out or Discuss for each candidate, with a one-line reason in Notes. Anything built as part of a job or for an employer is not a prior invention: suggest Out and say why. If it is unclear whether an item was my own work or done for an employer, suggest Discuss and add a question about it to the legal counsel list. If a record shows I shared an item with a company, for example while interviewing, suggest In and add a question about it to the legal counsel list. Suggest Discuss when you are not sure.

### STEP 3. Build my document

Build one document titled "[my name] - Prior Inventions" with three parts, in this order: Approval List, Register and Exhibit. Make it a Word file (.docx) if you can create files. If you cannot, use your own document editor if you have one. If you have neither, write it in the chat as formatted text with tables that I can paste into Word or Google Docs.

Fill in the Approval List now, using "Approval List layout" below. Under Register and Exhibit, put only the line "This part is filled in after you approve the Approval List."

Apply rule 8, then send me a short message with:

- the document, and how many candidates you found of each type;
- how many dates need me to confirm;
- the sources you could not reach;
- what to do next: set Include on each row to In, Out or Discuss, correct any date, answer the Confirm flags, then send "My approvals are done";
- this line: "This list is not legal advice. Review it with your own lawyer before you sign anything."

### STEP 4. Wait for my approvals

Stop and wait for me. Apply each change I give you to the Approval List. If I send back an edited copy of the document, work from my copy. When I say my approvals are done, check whether any row still says Discuss, and if so ask me about those rows only, in one message.

### STEP 5. Build the Register and Exhibit

1. Register: one entry for each row marked In, using "Register layout" below. Leave out every row marked Out.
2. Exhibit: one row for each item marked In, using "Exhibit layout" below. If I gave a company name and start date, fill them in. Otherwise leave those two cells blank.
3. On the Approval List, set the current version to 1.0 and add a revision history row: 1.0, today, the current time, "[your assistant's name], at [my name]'s direction", "Approved. Register and Exhibit built from the items marked In.", [my name].
4. Apply rule 8 to all three parts.
5. Give me the finished document. Tell me that the Exhibit is the only part meant for an employer, and that the Approval List and Register are confidential.

### STEP 6. Keep it current (only if I said yes in Step 1)

1. If you can save memories or standing instructions, offer to save this one, with the name of my document filled in: "When I finish building or designing something new, such as an app, tool, skill, prompt or method, ask whether to add it to my Prior Inventions document, [DOCUMENT NAME]. If I say yes, draft the Approval List row with the next free ID and dates tied to their records, and wait for my approval before changing anything." If you cannot save it, tell me to add it to my custom instructions myself.
2. Tell me that to add an item later, I can attach my document to a new chat with you and say: Add this to my Prior Inventions, following the rules in the Setup file. I should attach this Setup file too.
3. Ask whether I want a design document for any item marked In. If I do, build each one using "Design document layout" below.

### Approval List layout

- Title: "[my name] - Prior Inventions", then today's date and my name on one line.
- Heading "Document control", with a two-column table (Field, Value):

| Field | Value |
| --- | --- |
| Document ID | [my initials]-PI-001 |
| Owner | [my name]. Every item on this list is owned by [my name] personally. |
| Classification | Confidential (Approval List and Register). The Exhibit is written for disclosure. |
| Current version | 0.1 (Draft, becomes 1.0 on approval) |
| Review cycle | On every new invention, and before signing any employment or contractor agreement |
| Time zone | All times [my time zone] |

- Subheading "Revision history (oldest first)", with the columns Version, Date, Time, Author, Description of change and Approved by. The first row is: 0.1, today, the current time, "Claude, at [my name]'s direction" (or the name of the assistant writing it), "Initial draft: approval list of candidate inventions, with Register and Exhibit to follow.", Pending.
- Heading "How to use this list", then this paragraph: "Set the Include column on each row to In, Out or Discuss, and correct any date you know better. Rows marked In move to the Register with full detail, then to the Exhibit in general terms." Then these bullets:
  - Conceived is the earliest dated record of the idea. Built is the earliest dated record of a working version. "On or before" means the record proves the date was no later than that.
  - "Confirm" means no dated record was found. Fill in the date, or a date range you are confident of.
  - Each ID stays with its item for good: M for methodologies, S for software built, D for designed but not built.
- Heading "Methodologies", the line "Methods and frameworks that people apply, with or without software.", and a table with the columns ID, Item, What it is, Conceived, Built, Include and Notes.
- Heading "Software built", the line "Working apps, AI agents, skills and prompts, at least partly built.", and a table with the same columns.
- Heading "Designed, not built", the line "Conceived and documented, with no working version yet.", and a table with the columns ID, Item, What it is, Conceived, Include and Notes.
- Heading "Found, but not listed as inventions", the line "Claude found these in your work but did not count them as inventions, because they are outputs or reference material. If one of them is something you created and want listed, say so and it will be added.", and a short bulleted list.
- Heading "For legal counsel before you sign": one bullet per question. Start each with a bold label, name the companies and item IDs involved, and state the question to settle. Typical questions: work shared with a company while interviewing, a paid test project, work that overlaps the duties of a coming role, and items shared publicly. If there are none, write "No ownership questions were found."
- Heading "Where the dates come from": the sources searched, any that could not be reached, and this sentence: "Your own records, such as file dates, emails or code history, can move a date earlier."

In the Include column, use a dropdown with In, Out and Discuss if the docs tool offers one. Otherwise type the word. A sub-item sits on the row below its parent, with its ID (for example S-01.01).

### Register layout

- Heading "Register", then this paragraph: "One entry for every item marked In on the Approval List. Each entry covers the problem the item solves, the value it was designed to bring, how it works and what sets it apart, so any item can be explained without going back to the original work. Items marked Out are not carried here."
- For each item marked In, a heading "[ID] [item name]", then a table with the columns Type, Status, Conceived and Built. Each date keeps its record link.
- Then these paragraphs, each starting with its label in bold:
  - **Problem it solves.** What was hard or missing before this item.
  - **Value it was designed to bring.** What a person gains by using it.
  - **How it works.** The mechanism, in plain steps.
  - **What sets it apart.** How it differs from the usual way of doing the same job.
  - **Related.** IDs and item names only. Add "See the questions for legal counsel." when the item is on that list.
  - **Design documents.** A link, once one exists.
- A sub-item is covered in its parent's entry, or gets a short entry of its own right after its parent.
- Use only facts found in the records or given by me. If something is unknown, say what is unknown.

### Exhibit layout

- Title: "Exhibit: List of Prior Inventions".
- A two-column table (Field, Entry): Name, [my name]; Company, blank unless I gave one; Employment start date, blank unless I gave one; Date of this list, today.
- This paragraph: "Each item below was conceived, developed or reduced to practice by [my name] before the employment start date shown above, and is owned by [my name]. Descriptions are general and do not disclose confidential details. Dated records supporting each item are kept separately and are available on request. Item numbers match the owner's internal register. Gaps in the numbering are items that were merged into other items or are not claimed as inventions."
- Headings "Methodologies", "Software" and "Designs and concepts". Under each, a table with the columns ID, Title, Date and Description. Put the ID and Title in bold. The Date is the Conceived date; the month and year are enough. The Description is one or two general sentences. A sub-item is a row labelled "↳ S-01.01" with light gray shading. Leave out any heading that has no items.
- End with three lines to fill in by hand: Typed name, Signature and Date.

### Design document layout

One document per item, titled "[my name] - [ID] [item name] - Design":

- One sentence saying what the item is.
- Heading "Document control", with the fields Document ID ([my initials]-DES-[the ID without its hyphen, such as S05]), Item, Owner, Classification (Confidential), Current version (0.1, Draft, becomes 1.0 on approval), Status, Review cycle ("Every material change to the item or this design") and Time zone.
- Subheading "Revision history (oldest first)", with the same columns as on the Approval List.
- Heading "Dated milestones": a table with the columns Date, Milestone and Record that proves it, oldest first. Mark a row with no record "Confirm".
- Headings "Purpose" (a short paragraph), "Value" (bullets) and "How it works" (numbered steps). When the item is a process run partly by AI and partly by people, label each step AI (no person involved), AI / HITL (AI produces it and a person approves it) or HITL (a person does it), and explain the labels in a small table. HITL stands for human in the loop.
- Heading "Related items": a table with the columns ID and Item.
- Heading "To confirm": a checklist of open questions.
- Heading "Sources": a table with the columns Source (with neutral link text), Date of record and What it supports.
- Add the document's link to the item's Register entry.

---

New versions are posted at https://doovli.app/prior-inventions.html. Check there now and then.

(c) 2026 Rich Henderson. Shared under CC BY-NC 4.0: free to use and adapt for your own records, with credit. Not for resale or use in a paid product. Provided as is, with no warranty. This is not legal advice. You are responsible for reviewing everything it produces, including anything you sign or give to an employer.
